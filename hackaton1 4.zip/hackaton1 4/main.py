from flask import Flask, render_template, request, url_for, redirect
import ssl
import paho.mqtt.client as mqtt
import ast
import main2
import folium
from DataBase import JsonBase
import vonage

app = Flask(__name__)
data = JsonBase('data.json')


@app.route("/", methods=['POST', 'GET'])
def login():
    if request.method == "POST":
        t_login = request.form["login"]
        t_pas = request.form["pas"]
        check = data.read()
        if t_pas == check.get(t_login):
            return render_template('index.html')
        else:
            return "Out"
    else:
        return render_template("hack_log.html")


@app.route("/reg", methods=["POST", "GET"])
def reg():
    if request.method == "GET":
        return render_template("hack_reg.html")
    else:
        if request.form["pas1"] == request.form["pas2"]:
            data.add({request.form["login"]: request.form["pas1"]})
            return redirect('http://127.0.0.1:3010/login')
        else:
            return redirect(url_for("reg"))


@app.route("/map")
def index():

    tooltip = str(main2.thingId)
    popup_1 = str(main2.isWorking)
    popup_2 = str(main2.isWatering)
    lat = float(main2.current[0])
    lon = float(main2.current[1])
    m = folium.Map(location=[lat, lon], zoom_start=15)
    folium.Marker([lat, lon], popup=('Working: ' + popup_1 + "\n" + "Watering: " + popup_2), tooltip=tooltip).add_to(m)
    m.save('templates/map.html')
    return render_template("index.html")

@app.route("/call")
def call():

    clientt = vonage.Client(
        application_id="99fd2b99-f66f-49c0-9e08-d61bc71b280d",
        private_key="private.key",
    )

    voice = vonage.Voice(clientt)

    response = voice.create_call({
        'to': [{'type': 'phone', 'number': "79273123911"}],
        'from': {'type': 'phone', 'number': "79273123911"},
        'ncco': [{'action': 'talk', 'text': 'Good afternoon, I have found a problem with device, please check it.'}]
    })

    print(response)
    return render_template("call.html")

def on_subscribe(client, userdata, mid, granted_qos):
    print("Subscribed", client, userdata, mid, granted_qos)


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to broker")
        global Connected
        Connected = True
    else:
        print("Connection failed")


def on_message(client, userdata, message):
    print(f"Message received: {message.payload}")
    jsonString = message.payload
    dict_str = jsonString.decode("UTF-8")
    global jsonData
    jsonData = ast.literal_eval(dict_str)
    file1 = open("var.txt", "w+")
    file1.write(str(jsonData))


broker_address = "mqtt.cloud.yandex.net"
port = 8883
user = "aresmv64htqk8lkmqr61"
password = "ICLinnocamp2022"

client = mqtt.Client("kazanka")
client.username_pw_set(user, password=password)
client.on_connect = on_connect
client.on_message = on_message
client.on_subscribe = on_subscribe
client.tls_set(r"rootCA.crt", tls_version=ssl.PROTOCOL_TLSv1_2)
client.tls_insecure_set(True)
client.connect(broker_address, port=port)
client.subscribe("$devices/are9gnqohp4npug37mbs/events/raw")

if __name__ == "__main__":
    app.run(app.run(host= '0.0.0.0', port=3010))

client.loop_forever()
